function createModalDialog() {
	var modalDialog = document.createElementById("div");
	modalDialog.className = "ModalDialog";
}